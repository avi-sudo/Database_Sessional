--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Restaurant Finder And Rating App Database";
--
-- Name: Restaurant Finder And Rating App Database; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Restaurant Finder And Rating App Database" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "Restaurant Finder And Rating App Database" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Restaurant Finder And Rating App Database'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: add_review(character varying, character varying, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_review(rname character varying, uname character varying, comment text) RETURNS void
    LANGUAGE plpgsql
    AS $$declare
	count integer;
	rid integer;
	uid integer;
begin	
	select id from restaurant where name = rname into rid;
	select id from customer where username = uname into uid;
	select max(id) from review into count;
	insert into review values(count + 1, comment, current_date, rid, uid);
end;
$$;


ALTER FUNCTION public.add_review(rname character varying, uname character varying, comment text) OWNER TO postgres;

--
-- Name: basic_search(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.basic_search(value character varying, ordering integer) RETURNS TABLE(id integer, name character varying, rating real, address character varying)
    LANGUAGE plpgsql
    AS $$declare 
	q varchar;
	r record;
begin
	value := lower(value);
	q := '((select id, name, coalesce(rating,0) rr, area from restaurant where lower(name) like ''%' || value ||
	 '%'') union (select id, name , coalesce(rating,0) rr, area from restaurant where id in (select restaurant_id from 
	restaurant_has_food_category where food_category_id in (select id from food_category where lower(name) like ''%' || value || '%'' )))
	 union (select id, name , coalesce(rating,0) rr, area from restaurant where id in (select restaurant_id from 
	restaurant_has_cuisine where cuisine_id in (select id from cuisine where lower(name) like ''%' || value || '%'' )))';
	q := q || ' union (select id, name, coalesce(rating,0) rr, area from restaurant where lower(area) like ''%' || value || '%'' ))';
	
	if ordering = 1 then
		q := q || ' order by rr desc';
	else q := q || ' order by rr asc';
	end if;
	return query execute q;
	/*for r in execute q
	loop
		id := r.id;
		name := r.name;
		rating := round(r.rr::numeric, 2);
		address := r.area;
		return next;
	end loop;*/
end;$$;


ALTER FUNCTION public.basic_search(value character varying, ordering integer) OWNER TO postgres;

--
-- Name: create_list(character varying, character varying, boolean, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_list(lname character varying, des character varying, privacy boolean, uname character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$declare
	count integer;
	uid integer;
begin
	select id from customer where username = uname into uid;
	select count(*) from list where name = lname and user_id = uid into count;
	if count > 0 then
		return false;
	else
		select max(id) from list into count;
		insert into list values(count + 1, lname, des, privacy, current_date, uid);
		return true;
	end if;
end;
$$;


ALTER FUNCTION public.create_list(lname character varying, des character varying, privacy boolean, uname character varying) OWNER TO postgres;

--
-- Name: create_user(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_user(uname character varying, fname character varying, pass character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$declare
	count integer;
begin
	select count(*) from customer where username = uname into count;
	if count > 0 then
		return false;
	else
		select max(id) from customer into count;
		insert into customer values(count + 1, uname, fname, 0, pass);
		return true;
	end if;
end;
$$;


ALTER FUNCTION public.create_user(uname character varying, fname character varying, pass character varying) OWNER TO postgres;

--
-- Name: custom_insert(character varying, character varying, character varying, real); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.custom_insert(tname character varying, val1 character varying, val2 character varying, val3 real) RETURNS void
    LANGUAGE plpgsql
    AS $$declare
	count integer;
	id1 integer;
	id2 integer;
begin
	if tname = 'likes' or tname = 'visits' or tname = 'rates' then
		select id from customer where username = val1 into id1;
		select id from restaurant where name = val2 into id2;
		if tname = 'likes' then
			select count(*) from likes where user_id = id1 and restaurant_id = id2 into count;
			if count > 0 then
				delete from likes where user_id = id1 and restaurant_id = id2;
			else 
				select max(id) from likes into count;
				insert into likes values(coalesce(count,0)+1, id2, id1);
			end if;
		elsif tname = 'visits' then
			select count(*) from has_visited where user_id = id1 and restaurant_id = id2 into count;
			if count > 0 then
				update has_visited set date_visited = current_date where user_id = id1 and restaurant_id = id2;
				--delete from has_visited where user_id = id1 and restaurant_id = id2;
			else 
				select max(id) from has_visited into count;
				insert into has_visited values(coalesce(count,0)+1, current_date, id2, id1);
			end if;
		else 
			select count(*) from rates where user_id = id1 and restaurant_id = id2 into count;
			if count > 0 then
				update rates set rating = val3 where user_id = id1 and restaurant_id = id2;
			else 
				select max(id) from rates into count;
				insert into rates values(coalesce(count,0)+1, id2, val3, id1);
			end if;
		end if;
	else 
		select id from customer where username = val1 into id1;
		select id from customer where username = val2 into id2;
		select count(*) from follows where follower_id = id1 and followee_id = id2 into count;
		if count > 0 then
			delete from follows where follower_id = id1 and followee_id = id2;
		else 
			select max(id) from follows into count;
			insert into follows values(coalesce(count,0)+1, id1, id2);
		end if;
	end if;
end;
$$;


ALTER FUNCTION public.custom_insert(tname character varying, val1 character varying, val2 character varying, val3 real) OWNER TO postgres;

--
-- Name: enlist(character varying, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.enlist(rname character varying, lname character varying, uname character varying, remove boolean) RETURNS boolean
    LANGUAGE plpgsql
    AS $$declare 
	count integer;
	uid integer;
	rid integer;
	lid integer;
begin
	select id from restaurant where name = rname into rid;
	select id from customer where username = uname into uid;
	select id from list where name = lname and user_id = uid into lid;
	select count(*) from restaurant_is_in_list where restaurant_id = rid and list_id = lid into count;
	if count > 0 then
		if remove then
			delete from restaurant_is_in_list where restaurant_id = rid and list_id = lid;
		end if;
		return false;
	else
		select count(*) from restaurant_is_in_list into count;
		insert into restaurant_is_in_list values(count + 1, rid, lid, current_date);
		return true;
	end if;
end;
$$;


ALTER FUNCTION public.enlist(rname character varying, lname character varying, uname character varying, remove boolean) OWNER TO postgres;

--
-- Name: follower_update_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.follower_update_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$declare 
	count integer;
begin
	if new is not null then
		count := (select followers from customer where id = new.followee_id);
		update customer set followers = count + 1 where id = new.followee_id;
		return new;
	else
		count := (select followers from customer where id = old.followee_id);
		update customer set followers = count - 1 where id = old.followee_id;
		return old;
	end if;
end;
$$;


ALTER FUNCTION public.follower_update_trigger_func() OWNER TO postgres;

--
-- Name: like_update_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.like_update_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
	count integer;
begin
	if old is null then
		count := (select likes from restaurant where id = new.restaurant_id);
		update restaurant set likes = count + 1 where id = new.restaurant_id;
		return new;
	else 
		count := (select likes from restaurant where id = old.restaurant_id);
		update restaurant set likes = count - 1 where id = old.restaurant_id;
		return old;
	end if;
end;
$$;


ALTER FUNCTION public.like_update_trigger_func() OWNER TO postgres;

--
-- Name: main_search(character varying, integer, integer, integer, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, boolean, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.main_search(value character varying, ordering integer, prange integer, visited integer, liked boolean, listed boolean, lbpif boolean, wifi boolean, takeout boolean, delivery boolean, out_seat boolean, reservation boolean, credit_card boolean, parking boolean, uid integer) RETURNS TABLE(id integer, name character varying, rating real, address character varying, popularity integer)
    LANGUAGE plpgsql
    AS $$
declare 
	q varchar;
	r record;
	flag bool := false;
begin
	value := lower(value);
	q := '((select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where lower(name) like ''%' || value ||
	 '%'') union (select id, name , coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select restaurant_id from 
	restaurant_has_food_category where food_category_id in (select id from food_category where lower(name) like ''%' || value || '%'' )))
	 union (select id, name , coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select restaurant_id from 
	restaurant_has_cuisine where cuisine_id in (select id from cuisine where lower(name) like ''%' || value || '%'' )))';
	q := q || ' union (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where lower(area) like ''%' || value || '%'' )';
	q := q || ' union (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select restaurant_id from
	 review where lower(comment) like ''%' || value || '%'')))';
	
	if prange > 0 then
		q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where price_range = ' || quote_literal(prange) || ')';
	end if;
	
	if visited = 1 then
		q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select restaurant_id
		 from has_visited where user_id =' || quote_literal(uid) || '))';
	 elsif visited = 2 then
	    q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id not in (select restaurant_id
		 from has_visited where user_id =' || quote_literal(uid) || '))';
	 end if;
	 
	 if liked = true then
	 	q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select restaurant_id
		 from likes where user_id =' || quote_literal(uid) || '))';
	 end if;
	 
	 if listed = true then
	 	q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select r.restaurant_id
		 from list l, restaurant_is_in_list r where l.user_id =' || quote_literal(uid) || ' and r.list_id = l.id))';
	 end if;
	 	
	if lbpif = true then
		q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where id in (select l.restaurant_id
		 from likes l, follows f where f.follower_id =' || quote_literal(uid) || ' and l.user_id = f.followee_id))';
	end if;
	
	if wifi = true or takeout = true or delivery = true or out_seat = true or reservation = true or credit_card = true or parking = true then
		q := q || ' intersect (select id, name, coalesce(rating,0) rr, area, (likes+visits) pp from restaurant where';
		if wifi = true then
			flag = true;
			q := q || ' wifi = true';
		end if;
		if takeout = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' takeout = true';
			flag = true;
		end if;
		if delivery = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' delivery = true';
			flag = true;
		end if;
		if out_seat = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' outdoor_seating = true';
			flag = true;
		end if;
		if reservation = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' reservation = true';
			flag = true;
		end if;
		if credit_card = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' credit_card = true';
			flag = true;
		end if;
		if parking = true then
			if flag = true then q := q || ' and '; end if;
			q := q || ' parking = true';
			flag = true;
		end if;
		q := q || ')';
	end if;
	
	if ordering = 1 then
		q := q || ' order by rr desc';
	elsif ordering = 2 then 
		q := q || ' order by pp desc';
	end if;
	return query execute q;
	/*for r in execute q
	loop
		id := r.id;
		name := r.name;
		rating := round(r.rr::numeric, 2);
		address := r.area;
		return next;
	end loop;*/
end;
$$;


ALTER FUNCTION public.main_search(value character varying, ordering integer, prange integer, visited integer, liked boolean, listed boolean, lbpif boolean, wifi boolean, takeout boolean, delivery boolean, out_seat boolean, reservation boolean, credit_card boolean, parking boolean, uid integer) OWNER TO postgres;

--
-- Name: pass_encode_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.pass_encode_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$begin
	new.password = md5(new.password);
	return new;
end;
$$;


ALTER FUNCTION public.pass_encode_trigger_func() OWNER TO postgres;

--
-- Name: rating_update_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.rating_update_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$	declare
		count integer := 0;
		total real := 0;
	 	r record;
	begin
		for r in (select * from rates where restaurant_id = new.restaurant_id)
		loop
			count := count + 1;
			total := total + r.rating;
		end loop;
		update restaurant set rating = round((total / count)::numeric ,2) where id = new.restaurant_id;
		return new;
	end;
$$;


ALTER FUNCTION public.rating_update_trigger_func() OWNER TO postgres;

--
-- Name: visits_update_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.visits_update_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$declare 
	count integer;
begin
	if old is null then
		count := (select visits from restaurant where id = new.restaurant_id);
		update restaurant set visits = count + 1 where id = new.restaurant_id;
		return new;
	else 
		count := (select visits from restaurant where id = old.restaurant_id);
		update restaurant set visits = count - 1 where id = old.restaurant_id;
		return old;
	end if;
end;
$$;


ALTER FUNCTION public.visits_update_trigger_func() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cuisine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuisine (
    id integer NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public.cuisine OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    full_name character varying(50) NOT NULL,
    followers integer,
    password text NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follows (
    id integer NOT NULL,
    follower_id integer NOT NULL,
    followee_id integer NOT NULL
);


ALTER TABLE public.follows OWNER TO postgres;

--
-- Name: food_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_category (
    id integer NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public.food_category OWNER TO postgres;

--
-- Name: has_visited; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.has_visited (
    id integer NOT NULL,
    date_visited date,
    restaurant_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.has_visited OWNER TO postgres;

--
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    id integer NOT NULL,
    "time" timestamp with time zone,
    value character varying(100) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.history OWNER TO postgres;

--
-- Name: likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.likes (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.likes OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200),
    is_private boolean NOT NULL,
    date_created date,
    user_id integer NOT NULL
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: open_at; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.open_at (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    day character varying(4) NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


ALTER TABLE public.open_at OWNER TO postgres;

--
-- Name: rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rates (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    rating integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.rates OWNER TO postgres;

--
-- Name: restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    area character varying(25),
    contact_number character varying,
    price_range integer,
    rating real,
    wifi boolean,
    takeout boolean,
    delivery boolean,
    outdoor_seating boolean,
    reservation boolean,
    credit_card boolean,
    parking boolean,
    latitude real,
    longitude real,
    likes integer,
    visits integer
);


ALTER TABLE public.restaurant OWNER TO postgres;

--
-- Name: restaurant_has_cuisine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant_has_cuisine (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    cuisine_id integer NOT NULL
);


ALTER TABLE public.restaurant_has_cuisine OWNER TO postgres;

--
-- Name: restaurant_has_food_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant_has_food_category (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    food_category_id integer NOT NULL
);


ALTER TABLE public.restaurant_has_food_category OWNER TO postgres;

--
-- Name: restaurant_is_in_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant_is_in_list (
    id integer NOT NULL,
    restaurant_id integer NOT NULL,
    list_id integer NOT NULL,
    date_added date
);


ALTER TABLE public.restaurant_is_in_list OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    id integer NOT NULL,
    comment character varying(200),
    date date,
    restaurant_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Data for Name: cuisine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuisine (id, name) FROM stdin;
\.
COPY public.cuisine (id, name) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, username, full_name, followers, password) FROM stdin;
\.
COPY public.customer (id, username, full_name, followers, password) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follows (id, follower_id, followee_id) FROM stdin;
\.
COPY public.follows (id, follower_id, followee_id) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: food_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_category (id, name) FROM stdin;
\.
COPY public.food_category (id, name) FROM '$$PATH$$/2962.dat';

--
-- Data for Name: has_visited; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.has_visited (id, date_visited, restaurant_id, user_id) FROM stdin;
\.
COPY public.has_visited (id, date_visited, restaurant_id, user_id) FROM '$$PATH$$/2957.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (id, "time", value, user_id) FROM stdin;
\.
COPY public.history (id, "time", value, user_id) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.likes (id, restaurant_id, user_id) FROM stdin;
\.
COPY public.likes (id, restaurant_id, user_id) FROM '$$PATH$$/2956.dat';

--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, name, description, is_private, date_created, user_id) FROM stdin;
\.
COPY public.list (id, name, description, is_private, date_created, user_id) FROM '$$PATH$$/2952.dat';

--
-- Data for Name: open_at; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.open_at (id, restaurant_id, day, start_time, end_time) FROM stdin;
\.
COPY public.open_at (id, restaurant_id, day, start_time, end_time) FROM '$$PATH$$/2955.dat';

--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rates (id, restaurant_id, rating, user_id) FROM stdin;
\.
COPY public.rates (id, restaurant_id, rating, user_id) FROM '$$PATH$$/2960.dat';

--
-- Data for Name: restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant (id, name, area, contact_number, price_range, rating, wifi, takeout, delivery, outdoor_seating, reservation, credit_card, parking, latitude, longitude, likes, visits) FROM stdin;
\.
COPY public.restaurant (id, name, area, contact_number, price_range, rating, wifi, takeout, delivery, outdoor_seating, reservation, credit_card, parking, latitude, longitude, likes, visits) FROM '$$PATH$$/2951.dat';

--
-- Data for Name: restaurant_has_cuisine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant_has_cuisine (id, restaurant_id, cuisine_id) FROM stdin;
\.
COPY public.restaurant_has_cuisine (id, restaurant_id, cuisine_id) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: restaurant_has_food_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant_has_food_category (id, restaurant_id, food_category_id) FROM stdin;
\.
COPY public.restaurant_has_food_category (id, restaurant_id, food_category_id) FROM '$$PATH$$/2964.dat';

--
-- Data for Name: restaurant_is_in_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant_is_in_list (id, restaurant_id, list_id, date_added) FROM stdin;
\.
COPY public.restaurant_is_in_list (id, restaurant_id, list_id, date_added) FROM '$$PATH$$/2959.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (id, comment, date, restaurant_id, user_id) FROM stdin;
\.
COPY public.review (id, comment, date, restaurant_id, user_id) FROM '$$PATH$$/2953.dat';

--
-- Name: cuisine cuisine_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuisine
    ADD CONSTRAINT cuisine_name_key UNIQUE (name);


--
-- Name: cuisine cuisine_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuisine
    ADD CONSTRAINT cuisine_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: food_category food_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_category
    ADD CONSTRAINT food_category_name_key UNIQUE (name);


--
-- Name: food_category food_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_category
    ADD CONSTRAINT food_category_pkey PRIMARY KEY (id);


--
-- Name: has_visited has_visited_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.has_visited
    ADD CONSTRAINT has_visited_pkey PRIMARY KEY (id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: open_at open_at_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.open_at
    ADD CONSTRAINT open_at_pkey PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: restaurant_has_cuisine restaurant_has_cuisine_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_cuisine
    ADD CONSTRAINT restaurant_has_cuisine_pkey PRIMARY KEY (id);


--
-- Name: restaurant_has_food_category restaurant_has_food_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_food_category
    ADD CONSTRAINT restaurant_has_food_category_pkey PRIMARY KEY (id);


--
-- Name: restaurant_is_in_list restaurant_is_in_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_is_in_list
    ADD CONSTRAINT restaurant_is_in_list_pkey PRIMARY KEY (id);


--
-- Name: restaurant restaurant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT restaurant_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: fki_cid_fkey_rhc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_cid_fkey_rhc ON public.restaurant_has_cuisine USING btree (cuisine_id);


--
-- Name: fki_fcid_fkey_rhfc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_fcid_fkey_rhfc ON public.restaurant_has_food_category USING btree (food_category_id);


--
-- Name: fki_followee_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_followee_id_fkey ON public.follows USING btree (followee_id);


--
-- Name: fki_follower_id_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_follower_id_fkey ON public.follows USING btree (follower_id);


--
-- Name: fki_lid_fkey_isin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_lid_fkey_isin ON public.restaurant_is_in_list USING btree (list_id);


--
-- Name: fki_rid_fkey_hv; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_hv ON public.has_visited USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_isin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_isin ON public.restaurant_is_in_list USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_likes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_likes ON public.likes USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_openat; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_openat ON public.open_at USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_rates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_rates ON public.rates USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_review ON public.review USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_rhc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_rhc ON public.restaurant_has_cuisine USING btree (restaurant_id);


--
-- Name: fki_rid_fkey_rhfc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_rid_fkey_rhfc ON public.restaurant_has_food_category USING btree (restaurant_id);


--
-- Name: fki_user_id_fkey_has_visited; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_has_visited ON public.has_visited USING btree (user_id);


--
-- Name: fki_user_id_fkey_history; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_history ON public.history USING btree (user_id);


--
-- Name: fki_user_id_fkey_likes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_likes ON public.likes USING btree (user_id);


--
-- Name: fki_user_id_fkey_list; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_list ON public.list USING btree (user_id);


--
-- Name: fki_user_id_fkey_rates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_rates ON public.rates USING btree (user_id);


--
-- Name: fki_user_id_fkey_review; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_user_id_fkey_review ON public.review USING btree (user_id);


--
-- Name: follows follower_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER follower_update_trigger AFTER INSERT OR DELETE ON public.follows FOR EACH ROW EXECUTE PROCEDURE public.follower_update_trigger_func();


--
-- Name: likes like_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER like_update_trigger AFTER INSERT OR DELETE ON public.likes FOR EACH ROW EXECUTE PROCEDURE public.like_update_trigger_func();


--
-- Name: customer pass_encode_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER pass_encode_trigger BEFORE INSERT OR UPDATE ON public.customer FOR EACH ROW EXECUTE PROCEDURE public.pass_encode_trigger_func();


--
-- Name: rates rating_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER rating_update AFTER INSERT OR UPDATE ON public.rates FOR EACH ROW EXECUTE PROCEDURE public.rating_update_trigger_func();


--
-- Name: has_visited visits_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER visits_update_trigger AFTER INSERT OR DELETE ON public.has_visited FOR EACH ROW EXECUTE PROCEDURE public.visits_update_trigger_func();


--
-- Name: restaurant_has_cuisine cid_fkey_rhc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_cuisine
    ADD CONSTRAINT cid_fkey_rhc FOREIGN KEY (cuisine_id) REFERENCES public.cuisine(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_has_food_category fcid_fkey_rhfc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_food_category
    ADD CONSTRAINT fcid_fkey_rhfc FOREIGN KEY (food_category_id) REFERENCES public.food_category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: follows followee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT followee_id_fkey FOREIGN KEY (followee_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: follows follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_is_in_list lid_fkey_isin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_is_in_list
    ADD CONSTRAINT lid_fkey_isin FOREIGN KEY (list_id) REFERENCES public.list(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: has_visited rid_fkey_hv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.has_visited
    ADD CONSTRAINT rid_fkey_hv FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_is_in_list rid_fkey_isin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_is_in_list
    ADD CONSTRAINT rid_fkey_isin FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes rid_fkey_likes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT rid_fkey_likes FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: open_at rid_fkey_openat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.open_at
    ADD CONSTRAINT rid_fkey_openat FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rates rid_fkey_rates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rid_fkey_rates FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review rid_fkey_review; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT rid_fkey_review FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_has_cuisine rid_fkey_rhc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_cuisine
    ADD CONSTRAINT rid_fkey_rhc FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restaurant_has_food_category rid_fkey_rhfc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant_has_food_category
    ADD CONSTRAINT rid_fkey_rhfc FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: has_visited user_id_fkey_has_visited; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.has_visited
    ADD CONSTRAINT user_id_fkey_has_visited FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: history user_id_fkey_history; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT user_id_fkey_history FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes user_id_fkey_likes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT user_id_fkey_likes FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: list user_id_fkey_list; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT user_id_fkey_list FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rates user_id_fkey_rates; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT user_id_fkey_rates FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review user_id_fkey_review; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT user_id_fkey_review FOREIGN KEY (user_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

